## Los tests estan en el Frontend

## Reporte HTML
- Para ver el reporte ir a `frontend/mochawesome-report/mochawesome.html`.

## Link de los tests en ejecucion
- Para los tests en ejecucion ir a `https://youtu.be/yJbK9DfWblQ`.

## Link del tablero en Azure DevOps, historias de usuario
- Para ver las historias de usuario `https://dev.azure.com/202010403`.


##Francis Terrero 2020-10403
